#ifndef _SYSCALL_H_
#define _SYSCALL_H_

void syscall_handler(void);

#endif
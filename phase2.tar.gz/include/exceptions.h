#ifndef _EXCEPTIONS_H_
#define _EXCEPTIONS_H_

void trap_exception_handler(void);
void tlb_exception_handler(void);

#endif
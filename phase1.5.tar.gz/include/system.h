#include "const.h"
#include "types.h"

#ifdef TARGET_UMPS
#include "umps.h"
#endif
#ifdef TARGET_UARM
#include "uarm.h"
#endif

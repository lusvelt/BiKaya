#ifndef _PRINTER_H_
#define _PRINTER_H_

void prtr_puts(const char *str);

#endif
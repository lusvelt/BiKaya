#ifndef __PRINTER_H__
#define __PRINTER_H__

void prtr_puts(const char *str);

#endif
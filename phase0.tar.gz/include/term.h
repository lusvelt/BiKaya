#ifndef __TERM_H__
#define __TERM_H__

void term_puts(const char *str);
char *term_gets(char *buf, int size);

#endif
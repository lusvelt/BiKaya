#define NULL ((void *)0)

#define TRUE 1
#define FALSE 0
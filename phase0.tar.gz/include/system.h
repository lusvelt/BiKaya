#ifdef TARGET_UMPS
#include "umps/arch.h"
#include "umps/libumps.h"
#include "umps/types.h"
#endif
#ifdef TARGET_UARM
#include "uarm/arch.h"
#include "uarm/libuarm.h"
#include "uarm/uARMtypes.h"
#endif

#include "const.h"
